<h1>Email Verification Mail</h1>
  
Please verify your email with bellow link: 
    <a href="<?php echo e(route('auth.user.verify', $token)); ?>">Verify Email</a><?php /**PATH C:\CustomAuth\resources\views/emails/emailVerificationEmail.blade.php ENDPATH**/ ?>