

<?php $__env->startSection('content'); ?>

<div class="conatiner">
    <div class="row">
    <div class="col-3">
         your friends list
         <?php $__currentLoopData = $join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul id ="pendingdRequest">
                <?php if(Auth::user()->id == $ch->sender_id): ?>
                <a href="<?php echo e(route('letschat',$ch->reciver_id)); ?>"> <li id=" <?php echo e($ch->reciver_id); ?>"><?php echo e(getReciverName($ch->reciver_id)); ?></li></a>
                <?php else: ?>
                <a href="<?php echo e(route('letschat',$ch->sender_id)); ?>"><li id=" <?php echo e($ch->sender_id); ?>"><?php echo e(getReciverName($ch->sender_id)); ?></li></a>
                 
                <?php endif; ?>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-3">
            request pending at 
            <?php $__currentLoopData = $chat_sender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul id ="pendingdRequest"> 
                <li id=" <?php echo e($ch->reciver_id); ?>">
                <?php echo e($ch->reciver_id); ?>

               </li>
            
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-3">
            request recived from 
            <?php $__currentLoopData = $chat_reciver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_reciver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul id ="recivedRequest"> 
                <li id=" <?php echo e($_reciver->sender_id); ?>">
                <?php echo e($_reciver->sender_id); ?>

               </li>
            
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-3">
        click the user name to send the request
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul id="sendRequest"> 
                <li id="<?php echo e($user->id); ?>">
                   <?php echo e($user->name); ?>

               </li>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
    $('#sendRequest li').on('click', function() {
        var id  =$(this).attr('id');
        alert(id);
        $.ajax({
            headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                      },
            url:'sendReequest',
            type:'POST',
            data:{
                'id': id
            },
            success:function(data){
                alert(data);     
              }
            });


    });
    $('#recivedRequest li').on('click', function() {
        var id  =$(this).attr('id');
        alert(id);
        $.ajax({
            headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                      },
            url:'acceptReequest',
            type:'POST',
            data:{
                'id': id
            },
            success:function(data){
                alert(data);     
              }
            });


    });
});


    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CustomAuth\resources\views/auth/user/chat.blade.php ENDPATH**/ ?>