

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Welcome, <?php echo e(Auth::user()->name); ?></h2>

    <div class="row">
        <div class="col-6">
            <h4>Received Messages</h4>
            <?php $__currentLoopData = $join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::user()->id == $ch->reciver_id): ?>
                    <div><?php echo e($ch->sender_msg); ?></div>
                <?php else: ?>
                    <div><?php echo e($ch->reciver_msg); ?></div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="col-6">
            <h4>Sent Messages</h4>
            <?php $__currentLoopData = $join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::user()->id == $ch->sender_id): ?>
                    <div><?php echo e($ch->sender_msg); ?></div>
                <?php else: ?>
                    <div><?php echo e($ch->reciver_msg); ?></div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CustomAuth\resources\views/auth/user/chatgroup.blade.php ENDPATH**/ ?>