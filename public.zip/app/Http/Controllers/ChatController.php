<?php


namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Chat;
use App\Models\UserVerify;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Mail;
use DB;
use Hash;
use Session;
class ChatController extends Controller
{
    public function sendReequest(Request $request){
        $reciver_id = $request->id;
        $sender_id = Auth::user()->id;
        $confirmed  = 0;

        $counlist = Chat::where('sender_id', '=',$sender_id)
                        ->where('reciver_id','=', $reciver_id)
                        ->orWhere('reciver_id', '=',$sender_id)
                        ->where('sender_id','=', $reciver_id)->get();
        $total= $counlist->count();
    
        if($total<1){
            $created= Chat::create([
                'sender_id'=>$sender_id,
                'reciver_id'=>$reciver_id,
                'confirmed'=>$confirmed
            ]);
            if($created){
                return "yes";
            }else{
                return "no";
            }
    
        }else{
            return "You cannot sent more than on request one user";
        }
    }    

    public function acceptReequest(Request $request){
            $sender_id = $request->id;
            $receiver_id = Auth::user()->id;
            $value = Chat::where('sender_id', $sender_id)->where('reciver_id', $receiver_id);
                $value->update(['confirmed' => 1]);
            
                if($value ){
                    return "you have accepted the request of";
                }else{
                    return "try again ";
                }      
    }

    public function chatgroup($request){

        $reciver_id = $request;

        $join = DB::table('users')
        ->join('chat', 'users.id', '=', 'chat.sender_id')
        ->select('users.*', 'chat.*')
        ->where(function ($query) {
        $query->where('chat.sender_id', Auth::user()->id)
        ->orWhere('chat.reciver_id', Auth::user()->id);
        })
        ->where('chat.confirmed', '=', 1)
        ->where('chat.sender_id',$request )
        ->orWhere('chat.reciver_id', $request)
        ->get();
        return view('auth.user.chatgroup',compact('join')); 

    }
        
       
    
        
}
