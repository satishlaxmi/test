<!DOCTYPE html>
<html>
<head>
    <title>cybsersiffyphp artisan cache:clear.com</title>
</head>
<body>
    <h1>{{ $mailData['title'] }}</h1>
    <p>{{ $mailData['body'] }}</p>
  
    <p> THis is to verify that you have sucessfuly registered in the cybbersify go back and login </p>
     
    <p>Thank you</p>
</body>
</html>