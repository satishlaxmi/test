<h1>Email re Verification Mail</h1>
  
Please verify your email with bellow link: 
    <a href="{{ route('auth.user.verify', $token) }}">Verify Email</a>