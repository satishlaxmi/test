@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Welcome, {{ Auth::user()->name }}</h2>

    <div class="row">
        <div class="col-6">
            <h4>Received Messages</h4>
            @foreach($join as $ch)
                @if(Auth::user()->id == $ch->reciver_id)
                    <div>{{ $ch->sender_msg }}</div>
                @else
                    <div>{{ $ch->reciver_msg }}</div>
                @endif
            @endforeach
        </div>

        <div class="col-6">
            <h4>Sent Messages</h4>
            @foreach($join as $ch)
                @if(Auth::user()->id == $ch->sender_id)
                    <div>{{$ch->sender_msg }}</div>
                @else
                    <div>{{ $ch->reciver_msg      }}</div>
                @endif
            @endforeach
        </div>
    </div>
</div>
@endsection
